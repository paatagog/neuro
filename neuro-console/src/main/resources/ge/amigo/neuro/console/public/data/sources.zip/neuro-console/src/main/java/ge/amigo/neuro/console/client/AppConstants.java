package ge.amigo.neuro.console.client;

public class AppConstants {
	public static final String NEURO_SERVICE = "neuro_service";
	public static final String ICONS = "icons";
	public static final String MESSAGES = "messages";
}
