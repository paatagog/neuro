package ge.amigo.neuro.console.client.math.neuro;

public interface Neuron {
	
}