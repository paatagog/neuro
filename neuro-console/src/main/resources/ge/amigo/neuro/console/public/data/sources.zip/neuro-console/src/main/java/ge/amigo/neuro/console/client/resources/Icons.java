package ge.amigo.neuro.console.client.resources;

import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

public interface Icons extends ClientBundle {
	
	@Source("header-logo.png")
    ImageResource headerLogo();
	
}