package ge.amigo.neuro.console.client.mvc;

import com.extjs.gxt.ui.client.event.EventType;

public class AppEvents {
	public static final EventType INIT = new EventType();
}