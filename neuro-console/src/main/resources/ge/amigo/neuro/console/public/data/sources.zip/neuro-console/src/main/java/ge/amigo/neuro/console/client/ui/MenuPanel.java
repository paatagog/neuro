package ge.amigo.neuro.console.client.ui;

import com.extjs.gxt.ui.client.widget.Label;
import com.extjs.gxt.ui.client.widget.LayoutContainer;

public class MenuPanel extends LayoutContainer {

	public MenuPanel() {
		setStyleAttribute("border-right", "1px solid #FFFFFF");
		setStyleAttribute("padding-top", "5px");
		setStyleAttribute("padding-right", "5px");
		setStyleAttribute("padding-bottom", "5px");
		setStyleAttribute("padding-left", "5px");
		Label doc = new Label("<b><a href='./data/users_manual.doc'>დოკუმენტაცია</a></b><br/>");
		Label source = new Label("<b><a href='./data/source.zip'>საწყისი კოდი</a></b>");
		add(doc);
		add(source);
	}
}
